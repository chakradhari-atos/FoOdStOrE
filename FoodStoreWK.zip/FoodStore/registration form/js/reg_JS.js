function registration()
{
    var add=document.getElementById("t1").value;
    var email= document.getElementById("t2").value;
    var uname= document.getElementById("t3").value;
    var pwd= document.getElementById("t4").value; 
    var phn= document.getElementById("t5").value;          
    
    



    if(uname=='')
    {
        alert('Please enter the user name.');
    }
    else if(!letters.test(uname))
    {
        alert('User name field required only alphabet characters');
    }


    else if(email=='')
    {
        alert('Please enter your user email id');
    }
    else if (!filter.test(email))
    {
        alert('Invalid email');
    }


    else if(phn=='')
    {
        alert('Please enter Password');
    }


    else if(add=='')
    {
        alert('Please enter Password');
    }
  

    else if(pwd=='')
    {
        alert('Please enter Password');
    }
   
   

    else
    {                                           
           alert('Thank You for Registration & You are Redirecting to Website');
           // Redirecting to other page or webste code. 
           window.location = "https://tutorial.eyehunts.com//"; 
    }
}


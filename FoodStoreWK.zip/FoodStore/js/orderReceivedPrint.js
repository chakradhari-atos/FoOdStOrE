

function printDiv() {
    var print_div = document.getElementById("prt");
    var print_area = window.open();
    print_area.document.write(print_div.innerHTML);
    print_area.document.close();
    print_area.focus();
    print_area.print();
    print_area.close();
}

function log(){
document.getElementById("showdate").innerHTML=Date();
}

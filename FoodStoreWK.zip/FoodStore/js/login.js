
    

    
        function log() {
            var username = document.getElementById("user").value;
            var password = document.getElementById("password").value;

            if (username == "food" && password == "1234") {
                alert("hi user welcome to our page :)");

            }
            else {
                alert("sorry! invalid username/password :(");
            }
        }

  
    
        function myFunction() {
            var x = document.getElementById("myInput");
            if (x.type === "password") {
                x.type = "text";
            } else {
                x.type = "password";
            }
        }
    